const levels = {
  1: [[0,0], [3,3]],
  2: [[1,0], [2,1], [3,2]],
  3: [[0,0], [1,0], [2,0], [3,0], [1,1], [3,3]],
  4: { yellow: [[0,0], [2,2]], red: [[1,1]] }
};

let currentLevel = 0;

function startLevel(level) {
  currentLevel = level;
  document.getElementById("gameArea").innerHTML = "";

  const gameArea = document.getElementById("gameArea");

  const targetGrid = createGrid(level, true);
  const playerGrid = createGrid(level, false);

  gameArea.appendChild(targetGrid);
  gameArea.appendChild(playerGrid);
}

function createGrid(level, isTarget) {
  const grid = document.createElement("div");
  grid.className = "grid";

  for (let row = 0; row < 4; row++) {
    for (let col = 0; col < 4; col++) {
      const cell = document.createElement("div");
      cell.className = "cell";

      if (isTarget) {
        if (level < 4) {
          if (levels[level].some(([r, c]) => r === row && c === col)) {
            cell.classList.add("red");
          }
        } else {
          if (levels[4].red.some(([r, c]) => r === row && c === col)) {
            cell.classList.add("red");
          } else if (levels[4].yellow.some(([r, c]) => r === row && c === col)) {
            cell.classList.add("yellow");
          }
        }
      } else {
        cell.addEventListener("click", () => {
          if (level < 4) {
            cell.classList.toggle("red");
          } else {
            if (cell.classList.contains("red")) {
              cell.classList.remove("red");
              cell.classList.add("yellow");
            } else if (cell.classList.contains("yellow")) {
              cell.classList.remove("yellow");
            } else {
              cell.classList.add("red");
            }
          }
          checkWin();
        });
      }

      grid.appendChild(cell);
    }
  }

  return grid;
}

function checkWin() {
  const grids = document.querySelectorAll(".grid");
  if (grids.length < 2) return;

  const targetCells = grids[0].children;
  const playerCells = grids[1].children;

  for (let i = 0; i < 16; i++) {
    const target = targetCells[i].className;
    const player = playerCells[i].className;
    if (target !== player) return;
  }

  showTrophy();
}

function showTrophy() {
  const trophy = document.getElementById("trophy");
  const message = document.getElementById("message");

  trophy.classList.remove("hidden");

  if (currentLevel < 4) {
    message.textContent = `Livello ${currentLevel} completato!`;
    document.getElementById(`level${currentLevel + 1}`).disabled = false;
  } else {
    message.textContent = "Sei un campione!";
    trophy.style.fontSize = "48px";
  }
}
